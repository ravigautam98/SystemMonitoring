﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPUMonitoring.Model
{
    public class SystemMetrics
    {
        public float Cpu { get; set; }
        public float TotalRam { get; set; }
        public float RamUsed { get; set; }
        public float TotalDisk { get; set; }
        public float DiskUsed { get; set; }
    }
}
