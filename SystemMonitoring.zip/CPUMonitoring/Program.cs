﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Serilog;
using System.Runtime.InteropServices;
using CPUMonitoring.Interface;
using CPUMonitoring.Services;
using CPUMonitoring.Plugins;

namespace CPUMonitoring
{
    class Program
    {
        static async Task Main(string[] args)
        {
            try
            {
                var basePath = AppContext.BaseDirectory;
                var projectRoot = Path.GetFullPath(Path.Combine(basePath, "..", "..", ".."));
                var logPath = Path.Combine(projectRoot, "Logs");

                // Ensure directory exists
                if (!Directory.Exists(logPath))
                {
                    Directory.CreateDirectory(logPath);
                }

                // Configure Serilog
                Log.Logger = new LoggerConfiguration()
                    .WriteTo.Console()
                    .WriteTo.File(Path.Combine(logPath, "metrics.log"), rollingInterval: RollingInterval.Day)
                    .CreateLogger();

                var host = CreateHostBuilder(args).Build();
                await host.RunAsync(); // Run hosted services 
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "Host terminated unexpectedly.");
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .UseSerilog() // Hook Serilog into generic host
                .ConfigureAppConfiguration((context, config) =>
                {
                    config.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
                })
                .ConfigureServices((hostContext, services) =>
                {
                    var config = hostContext.Configuration;
                    var apiUrl = config.GetValue<string>("ApiPlugin:Url");

                    //Cross Platform compatibility - For now added only for windows
                    //but can make new service for linux and mac as they are seperate and
                    //will just need interface for implementations

                    if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                    {
                        services.AddSingleton<IMonitorService, WindowMonitor>();
                    }
                    else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                    {
                        services.AddSingleton<IMonitorService, LinuxMonitor>();
                    }
                    else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                    {
                        //services.AddSingleton<IMonitorService, MacMonitor>(); 
                    }
                    else
                    {
                        throw new PlatformNotSupportedException("Unsupported operating system.");
                    }

                    //services.AddSingleton<IMonitorService, WindowMonitor>();
                    //services.AddSingleton<IMonitorService, LinuxMonitor>();
                    services.AddSingleton<IConfiguration>(hostContext.Configuration);
                    services.AddSingleton<IMonitorPlugin>(new APIPlugin(apiUrl));
                    services.AddHostedService<MonitoringService>(); // Background service
                });
    }
}

