﻿using CPUMonitoring.Interface;
using CPUMonitoring.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management;


namespace CPUMonitoring.Services
{
    class WindowMonitor : IMonitorService
    {
        private readonly PerformanceCounter _cpuCounter;
        private readonly PerformanceCounter _ramAvailableCounter;
        private readonly float _totalRamInMb;

        public WindowMonitor()
        {
            _cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            _ramAvailableCounter = new PerformanceCounter("Memory", "Available MBytes");

            //using wmi to get RAM
            _totalRamInMb = GetTotalRamInMb(); // fallback to 8 GB
            _cpuCounter.NextValue(); // Warm up
        }

        public async Task<SystemMetrics> GetMetricsAsync()
        {
            await Task.Delay(1000); // CPU needs a delay to give real reading
            float cpu = _cpuCounter.NextValue();

            float ramAvailableMb = _ramAvailableCounter.NextValue();
            float ramUsedMb = _totalRamInMb - ramAvailableMb;

            var readyDrives = DriveInfo.GetDrives()
                .Where(d => d.IsReady && d.DriveType == DriveType.Fixed)
                .ToList();

            float totalDiskMb = readyDrives.Sum(d => d.TotalSize) / (1024f * 1024f);     // MB
            float diskUsedMb = readyDrives.Sum(d => d.TotalSize - d.TotalFreeSpace) / (1024f * 1024f); // MB

            // Convert MB to GB
            float ramUsedGb = ramUsedMb / 1024f;
            float totalRamGb = _totalRamInMb / 1024f;
            float diskUsedGb = diskUsedMb / 1024f;
            float totalDiskGb = totalDiskMb / 1024f;

            return new SystemMetrics
            {
                Cpu = cpu,
                RamUsed = ramUsedGb,
                TotalRam = totalRamGb,
                DiskUsed = diskUsedGb,
                TotalDisk = totalDiskGb
            };
        }

        private float GetTotalRamInMb()
        {
            try
            {
                var searcher = new System.Management.ManagementObjectSearcher("SELECT TotalPhysicalMemory FROM Win32_ComputerSystem");
                foreach (var obj in searcher.Get())
                {
                    if (obj["TotalPhysicalMemory"] != null)
                    {
                        // Convert bytes to MB
                        ulong totalBytes = (ulong)obj["TotalPhysicalMemory"];
                        return totalBytes / (1024f * 1024f);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to get total RAM via WMI: " + ex.Message);
            }

            // Fallback to 8 GB (8192 MB)
            return 8192f;
        }
    }
}
