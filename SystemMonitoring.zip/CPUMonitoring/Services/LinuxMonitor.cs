﻿using CPUMonitoring.Interface;
using CPUMonitoring.Model;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

class LinuxMonitor : IMonitorService
{
    public async Task<SystemMetrics> GetMetricsAsync()
    {
        float cpu = /*await GetCpuUsageAsync();*/0;
        (float ramUsed, float totalRam) = /*GetRamUsage()*/(0, 100);
        (float diskUsed, float totalDisk) = GetDiskUsage();

        return new SystemMetrics
        {
            Cpu = cpu,
            RamUsed = ramUsed,
            TotalRam = totalRam,
            DiskUsed = diskUsed,
            TotalDisk = totalDisk
        };
    }

    private async Task<float> GetCpuUsageAsync()
    {
        string[] lines1 = await File.ReadAllLinesAsync("/proc/stat");
        string cpuLine1 = lines1.First(l => l.StartsWith("cpu "));
        var values1 = cpuLine1.Split(' ', StringSplitOptions.RemoveEmptyEntries).Skip(1).Select(float.Parse).ToArray();
        float idle1 = values1[3];
        float total1 = values1.Sum();

        await Task.Delay(1000); // wait 1 second

        string[] lines2 = await File.ReadAllLinesAsync("/proc/stat");
        string cpuLine2 = lines2.First(l => l.StartsWith("cpu "));
        var values2 = cpuLine2.Split(' ', StringSplitOptions.RemoveEmptyEntries).Skip(1).Select(float.Parse).ToArray();
        float idle2 = values2[3];
        float total2 = values2.Sum();

        float totalDiff = total2 - total1;
        float idleDiff = idle2 - idle1;

        return 100f * (1f - (idleDiff / totalDiff));
    }

    private (float Used, float Total) GetRamUsage()
    {
        var lines = File.ReadAllLines("/proc/meminfo");

        float total = float.Parse(lines.First(l => l.StartsWith("MemTotal")).Split(':')[1].Trim().Split(' ')[0]) / 1024f;
        float available = float.Parse(lines.First(l => l.StartsWith("MemAvailable")).Split(':')[1].Trim().Split(' ')[0]) / 1024f;
        float used = total - available;

        return (used, total);
    }

    private (float Used, float Total) GetDiskUsage()
    {
        var drives = DriveInfo.GetDrives().Where(d => d.IsReady && d.DriveType == DriveType.Fixed);
        float total = drives.Sum(d => d.TotalSize) / (1024f * 1024f * 1024f);
        float used = drives.Sum(d => d.TotalSize - d.TotalFreeSpace) / (1024f * 1024f * 1024f);
        return (used, total);
    }
}
