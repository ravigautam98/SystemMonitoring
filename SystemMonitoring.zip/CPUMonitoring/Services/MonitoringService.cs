﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Threading;
using System.Threading.Tasks;
using CPUMonitoring.Interface;

namespace CPUMonitoring.Services
{
    public class MonitoringService : BackgroundService
    {
        private readonly IMonitorService _monitorService;
        private readonly IMonitorPlugin _plugin;
        private readonly ILogger<MonitoringService> _logger;
        private readonly int _intervalInSeconds;

        public MonitoringService(
            IMonitorService monitorService,
            ILogger<MonitoringService> logger,
            IMonitorPlugin plugin,
            IConfiguration config)
        {
            _monitorService = monitorService;
            _logger = logger;
            _plugin = plugin;
            _intervalInSeconds = config.GetValue("IntervalInSeconds", 10); // default to 10s
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                var metrics = await _monitorService.GetMetricsAsync();

                _logger.LogInformation("CPU: {Cpu}% | RAM Used: {RamUsed:F2}GB / {TotalRam:F2}GB | Disk Used: {DiskUsed:F2}GB / {TotalDisk:F2}GB",
                    metrics.Cpu, metrics.RamUsed, metrics.TotalRam, metrics.DiskUsed, metrics.TotalDisk);

                await _plugin.HandleMetricsAsync(metrics);

                await Task.Delay(_intervalInSeconds * 1000, stoppingToken);
            }
        }
    }
}

