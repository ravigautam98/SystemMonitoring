﻿using CPUMonitoring.Interface;
using CPUMonitoring.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace CPUMonitoring.Plugins
{
    class APIPlugin : IMonitorPlugin
    {
        private readonly string _apiUrl;

        public APIPlugin(string apiUrl)
        {
            _apiUrl = apiUrl;
        }

        public async Task HandleMetricsAsync(SystemMetrics metrics)
        {
            var payload = new
            {
                Cpu = metrics.Cpu,
                RamUsed = $"{metrics.RamUsed:F2} GB",
                TotalRam = $"{metrics.TotalRam:F2} GB",
                DiskUsed = $"{metrics.DiskUsed:F2} GB",
                TotalDisk = $"{metrics.TotalDisk:F2} GB"
            };
            using var client = new HttpClient();
            var json = JsonSerializer.Serialize(payload);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync(_apiUrl, content);
            Console.WriteLine($"Sent metrics to API. Status: {response.StatusCode}");
        }
    }
}
