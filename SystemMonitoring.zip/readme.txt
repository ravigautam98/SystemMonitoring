System Monitoring Console App (C# .NET 8)
=========================================================

This is a system monitoring console application built with .NET 8. It gathers CPU, RAM, and Disk usage metrics using OS-specific plugins and logs them using Serilog. It also supports sending metrics to an API. 

---------------------------------------------------------
Features
---------------------------------------------------------
- CPU, RAM, and Disk usage monitoring
- Plugin architecture for Windows, Linux, macOS using interface
- Console and file logging (Serilog)
- Configurable via appsettings.json
- Background service using IHost
- Easy to extend with custom plugins
- Completely working architecture for window OS can extend to other OS for cross platform support.

---------------------------------------------------------
Folder Structure
---------------------------------------------------------
CPUMonitoring/
│
├── Interfaces/
│   └── IMonitorService.cs
│   └── IMonitorPlugin.cs
│
├── Models/
│   └── SystemMetrics.cs
│
├── Plugins/
│   └── APIPlugin.cs  (For posting JSON data )
│
├── Services/
│   └── MonitoringService.cs
│   └── WindowMonitor.cs (Complete working logic)
|   └── LinuxMonitor.cs (Placeholder/ For demo purpose)
|
│
├── Logs/
│   └── (Serilog outputs here with logs name including dates)
│
├── appsettings.json
└── Program.cs

Configuration file include API plugin and API endpoint where JSON data is posted. This API endpoint is used for posting data "https://67fab2598ee14a54262865c8.mockapi.io/metrics".
---------------------------------------------------------
Configuration (appsettings.json)
---------------------------------------------------------
{
  "IntervalInSeconds": 5,
  "ApiPlugin": {
    "Url": "https://67fab2598ee14a54262865c8.mockapi.io/metrics"
  },
  "FileLoggerPlugin": {
    "Enabled": true,
    "LogFilePath": "metrics.log"
  }
}

---------------------------------------------------------
How to Build and Run
---------------------------------------------------------
1. Prerequisites:
   - .NET 8 SDK installed

2. Build:
   - dotnet build

3. Run:
   - dotnet run

Run the above command in command prompt in the directory where .csproj file is located.

Alternatively - 
To run this application, open it in VS2022 and then build the solution, while running it will launch the console terminal and will start logging the info.

---------------------------------------------------------
How It Works
---------------------------------------------------------
- On startup, detects OS using RuntimeInformation
- Registers the correct monitor plugin
- Fetches system metrics every 5 seconds (from config)
- Logs metrics and optionally sends to API
- LinuxMonitor is also implemented as placeholder to show the plugin capability of code without changing core logic.

Example Log Output:
CPU: 15.45% | RAM Used: 2.54 GB / 8.00 GB | Disk Used: 100.00 GB / 256.00 GB

---------------------------------------------------------
Extendability
---------------------------------------------------------
To add a new plugin:
1. Implement IMonitorPlugin
2. Register using:
   services.AddSingleton<IMonitorPlugin, YourPlugin>();

---------------------------------------------------------
Author
---------------------------------------------------------
Ravikant Gautam

